from fastapi import FastAPI
from pydantic import BaseModel
from sql_agent import generate_sql, execute_sql, explain_result

app = FastAPI()


class Question(BaseModel):
    question: str


@app.post("/ask")
def ask(question: Question):

    sql = generate_sql(question.question)

    result = execute_sql(sql)

    answer = explain_result(
        question.question,
        str(result)
    )

    return {
        "question": question.question,
        "generated_sql": sql,
        "result": str(result),
        "answer": answer
    }