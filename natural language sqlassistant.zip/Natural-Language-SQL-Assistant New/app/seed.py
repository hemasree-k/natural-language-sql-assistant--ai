from database import engine
from models import Base
from sqlalchemy import text

Base.metadata.create_all(
    bind=engine
)

with engine.connect() as conn:

    conn.execute(
        text("""
        INSERT INTO employees
        (name,department,salary)

        VALUES

        ('John','Engineering',70000),
        ('Emma','Engineering',90000),
        ('Alex','HR',50000),
        ('Sophia','Sales',80000),
        ('David','Engineering',120000)
        """)
    )

    conn.commit()

print("Database Created")