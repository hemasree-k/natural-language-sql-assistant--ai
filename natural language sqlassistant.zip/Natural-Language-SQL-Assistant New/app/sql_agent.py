import os
import pandas as pd
from dotenv import load_dotenv
from sqlalchemy import create_engine

from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_community.utilities import SQLDatabase


# Load environment variables
load_dotenv()

# Database path
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE_URL = f"sqlite:///{BASE_DIR}/database/company.db"

# Database connection
db = SQLDatabase.from_uri(DATABASE_URL)
engine = create_engine(DATABASE_URL)

# Gemini model
llm = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash",
    google_api_key=os.getenv("GOOGLE_API_KEY")
)


def generate_sql(question):

    schema = db.get_table_info()

    prompt = f"""
You are an SQL expert.

Database schema:
{schema}

Convert ONLY into SQL.

Question:
{question}

Return SQL only.
"""

    response = llm.invoke(prompt)

    return response.content.strip()


def execute_sql(sql):

    try:

        clean_sql = (
            sql.replace("```sql", "")
            .replace("```", "")
            .strip()
        )

        result = pd.read_sql(
            clean_sql,
            engine
        )

        return result

    except Exception as e:

        return str(e)


def explain_result(question, data):

    prompt = f"""
User Question:
{question}

Database Output:
{data}

Explain naturally.
"""

    answer = llm.invoke(prompt)

    return answer.content