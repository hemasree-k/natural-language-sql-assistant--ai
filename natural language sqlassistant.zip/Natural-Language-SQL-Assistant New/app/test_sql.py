from sql_agent import (
    generate_sql,
    execute_sql,
    explain_result
)

question = input("Ask: ")

sql = generate_sql(question)

print("\nSQL:\n")
print(sql)

result = execute_sql(sql)

print("\nRESULT:\n")
print(result)

answer = explain_result(
    question,
    str(result)
)

print("\nAI ANSWER:\n")
print(answer)